
  async function setBackgroundGIF() {
    document.body.style.backgroundImage = `url("https://i.gifer.com/fxn8.gif")`;
  }
  
  setBackgroundGIF();